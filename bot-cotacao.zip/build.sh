#!/bin/bash

zip -r "bot-cotacao.zip" * -x "bot-cotacao.zip"